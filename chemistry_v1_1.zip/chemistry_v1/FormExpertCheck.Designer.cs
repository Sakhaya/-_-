﻿
namespace chemistry_v1
{
    partial class FormExpertCheck
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_expert = new System.Windows.Forms.Panel();
            this.button_check = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.panel_chem_sub = new System.Windows.Forms.Panel();
            this.dataGridView_res_yes = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView_reagent_yes = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.text1 = new System.Windows.Forms.Label();
            this.dataGridView_molm_yes = new System.Windows.Forms.DataGridView();
            this.button_res = new System.Windows.Forms.Button();
            this.button_reagent = new System.Windows.Forms.Button();
            this.button_reaction = new System.Windows.Forms.Button();
            this.button_mol_m = new System.Windows.Forms.Button();
            this.button_chem_sub = new System.Windows.Forms.Button();
            this.panel_text_auth = new System.Windows.Forms.Panel();
            this.button_close = new System.Windows.Forms.Button();
            this.label_editBZ = new System.Windows.Forms.Label();
            this.dataGridView_molm_no = new System.Windows.Forms.DataGridView();
            this.dataGridView_reagent_no = new System.Windows.Forms.DataGridView();
            this.dataGridView_res_no = new System.Windows.Forms.DataGridView();
            this.panel_expert.SuspendLayout();
            this.panel_chem_sub.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_res_yes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_reagent_yes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_molm_yes)).BeginInit();
            this.panel_text_auth.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_molm_no)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_reagent_no)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_res_no)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_expert
            // 
            this.panel_expert.BackColor = System.Drawing.SystemColors.Menu;
            this.panel_expert.Controls.Add(this.button_check);
            this.panel_expert.Controls.Add(this.button_exit);
            this.panel_expert.Controls.Add(this.panel_chem_sub);
            this.panel_expert.Controls.Add(this.button_res);
            this.panel_expert.Controls.Add(this.button_reagent);
            this.panel_expert.Controls.Add(this.button_reaction);
            this.panel_expert.Controls.Add(this.button_mol_m);
            this.panel_expert.Controls.Add(this.button_chem_sub);
            this.panel_expert.Controls.Add(this.panel_text_auth);
            this.panel_expert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_expert.Location = new System.Drawing.Point(0, 0);
            this.panel_expert.Name = "panel_expert";
            this.panel_expert.Size = new System.Drawing.Size(548, 447);
            this.panel_expert.TabIndex = 5;
            this.panel_expert.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_expert_MouseDown);
            this.panel_expert.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_expert_MouseMove);
            // 
            // button_check
            // 
            this.button_check.BackColor = System.Drawing.Color.ForestGreen;
            this.button_check.FlatAppearance.BorderSize = 0;
            this.button_check.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_check.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_check.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_check.Location = new System.Drawing.Point(0, 357);
            this.button_check.Name = "button_check";
            this.button_check.Size = new System.Drawing.Size(113, 51);
            this.button_check.TabIndex = 10;
            this.button_check.Text = "Проверка полноты знаний ";
            this.button_check.UseVisualStyleBackColor = false;
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button_exit.FlatAppearance.BorderSize = 0;
            this.button_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_exit.Location = new System.Drawing.Point(0, 414);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(107, 21);
            this.button_exit.TabIndex = 9;
            this.button_exit.Text = "Выйти";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // panel_chem_sub
            // 
            this.panel_chem_sub.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_chem_sub.Controls.Add(this.dataGridView_res_no);
            this.panel_chem_sub.Controls.Add(this.dataGridView_reagent_no);
            this.panel_chem_sub.Controls.Add(this.dataGridView_molm_no);
            this.panel_chem_sub.Controls.Add(this.dataGridView_res_yes);
            this.panel_chem_sub.Controls.Add(this.label2);
            this.panel_chem_sub.Controls.Add(this.dataGridView_reagent_yes);
            this.panel_chem_sub.Controls.Add(this.label1);
            this.panel_chem_sub.Controls.Add(this.text1);
            this.panel_chem_sub.Controls.Add(this.dataGridView_molm_yes);
            this.panel_chem_sub.Location = new System.Drawing.Point(113, 37);
            this.panel_chem_sub.Name = "panel_chem_sub";
            this.panel_chem_sub.Size = new System.Drawing.Size(423, 398);
            this.panel_chem_sub.TabIndex = 8;
            // 
            // dataGridView_res_yes
            // 
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_res_yes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView_res_yes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_res_yes.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_res_yes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridView_res_yes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_res_yes.DefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridView_res_yes.Location = new System.Drawing.Point(16, 293);
            this.dataGridView_res_yes.Name = "dataGridView_res_yes";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_res_yes.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_res_yes.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridView_res_yes.Size = new System.Drawing.Size(190, 85);
            this.dataGridView_res_yes.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(0, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(419, 36);
            this.label2.TabIndex = 17;
            this.label2.Text = "Результаты";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridView_reagent_yes
            // 
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_reagent_yes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.dataGridView_reagent_yes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_reagent_yes.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_reagent_yes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dataGridView_reagent_yes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_reagent_yes.DefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridView_reagent_yes.Location = new System.Drawing.Point(16, 166);
            this.dataGridView_reagent_yes.Name = "dataGridView_reagent_yes";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_reagent_yes.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_reagent_yes.RowsDefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridView_reagent_yes.Size = new System.Drawing.Size(190, 85);
            this.dataGridView_reagent_yes.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(0, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(419, 36);
            this.label1.TabIndex = 15;
            this.label1.Text = "Реагенты";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text1
            // 
            this.text1.Dock = System.Windows.Forms.DockStyle.Top;
            this.text1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.text1.Location = new System.Drawing.Point(0, 0);
            this.text1.Name = "text1";
            this.text1.Size = new System.Drawing.Size(419, 36);
            this.text1.TabIndex = 14;
            this.text1.Text = "Молярная масса";
            this.text1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridView_molm_yes
            // 
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_molm_yes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridView_molm_yes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_molm_yes.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_molm_yes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridView_molm_yes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_molm_yes.DefaultCellStyle = dataGridViewCellStyle28;
            this.dataGridView_molm_yes.Location = new System.Drawing.Point(16, 39);
            this.dataGridView_molm_yes.Name = "dataGridView_molm_yes";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_molm_yes.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_molm_yes.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.dataGridView_molm_yes.Size = new System.Drawing.Size(190, 85);
            this.dataGridView_molm_yes.TabIndex = 13;
            // 
            // button_res
            // 
            this.button_res.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_res.FlatAppearance.BorderSize = 0;
            this.button_res.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_res.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_res.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_res.Location = new System.Drawing.Point(0, 213);
            this.button_res.Name = "button_res";
            this.button_res.Size = new System.Drawing.Size(107, 38);
            this.button_res.TabIndex = 7;
            this.button_res.Text = "Результаты ";
            this.button_res.UseVisualStyleBackColor = false;
            this.button_res.Click += new System.EventHandler(this.button_res_Click);
            // 
            // button_reagent
            // 
            this.button_reagent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_reagent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_reagent.FlatAppearance.BorderSize = 0;
            this.button_reagent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reagent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_reagent.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_reagent.Location = new System.Drawing.Point(0, 169);
            this.button_reagent.Name = "button_reagent";
            this.button_reagent.Size = new System.Drawing.Size(107, 38);
            this.button_reagent.TabIndex = 6;
            this.button_reagent.Text = "Реагенты";
            this.button_reagent.UseVisualStyleBackColor = false;
            this.button_reagent.Click += new System.EventHandler(this.button_reagent_Click);
            // 
            // button_reaction
            // 
            this.button_reaction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_reaction.FlatAppearance.BorderSize = 0;
            this.button_reaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_reaction.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_reaction.Location = new System.Drawing.Point(0, 125);
            this.button_reaction.Name = "button_reaction";
            this.button_reaction.Size = new System.Drawing.Size(107, 38);
            this.button_reaction.TabIndex = 5;
            this.button_reaction.Text = "Реакции";
            this.button_reaction.UseVisualStyleBackColor = false;
            this.button_reaction.Click += new System.EventHandler(this.button_reaction_Click);
            // 
            // button_mol_m
            // 
            this.button_mol_m.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_mol_m.FlatAppearance.BorderSize = 0;
            this.button_mol_m.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mol_m.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_mol_m.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_mol_m.Location = new System.Drawing.Point(0, 81);
            this.button_mol_m.Name = "button_mol_m";
            this.button_mol_m.Size = new System.Drawing.Size(107, 38);
            this.button_mol_m.TabIndex = 4;
            this.button_mol_m.Text = "Молярная масса";
            this.button_mol_m.UseVisualStyleBackColor = false;
            this.button_mol_m.Click += new System.EventHandler(this.button_mol_m_Click);
            // 
            // button_chem_sub
            // 
            this.button_chem_sub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_chem_sub.FlatAppearance.BorderSize = 0;
            this.button_chem_sub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_chem_sub.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_chem_sub.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_chem_sub.Location = new System.Drawing.Point(0, 37);
            this.button_chem_sub.Name = "button_chem_sub";
            this.button_chem_sub.Size = new System.Drawing.Size(107, 38);
            this.button_chem_sub.TabIndex = 3;
            this.button_chem_sub.Text = "Химические вещества";
            this.button_chem_sub.UseVisualStyleBackColor = false;
            this.button_chem_sub.Click += new System.EventHandler(this.button_chem_sub_Click);
            // 
            // panel_text_auth
            // 
            this.panel_text_auth.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_text_auth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_text_auth.Controls.Add(this.button_close);
            this.panel_text_auth.Controls.Add(this.label_editBZ);
            this.panel_text_auth.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_text_auth.Location = new System.Drawing.Point(0, 0);
            this.panel_text_auth.Name = "panel_text_auth";
            this.panel_text_auth.Size = new System.Drawing.Size(548, 31);
            this.panel_text_auth.TabIndex = 2;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Red;
            this.button_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_close.FlatAppearance.BorderSize = 0;
            this.button_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_close.Location = new System.Drawing.Point(525, -1);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(22, 20);
            this.button_close.TabIndex = 1;
            this.button_close.Text = "X";
            this.button_close.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.button_close.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button_close.UseVisualStyleBackColor = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // label_editBZ
            // 
            this.label_editBZ.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label_editBZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_editBZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_editBZ.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label_editBZ.Location = new System.Drawing.Point(0, 0);
            this.label_editBZ.Name = "label_editBZ";
            this.label_editBZ.Size = new System.Drawing.Size(546, 29);
            this.label_editBZ.TabIndex = 0;
            this.label_editBZ.Text = "Редактор базы знаний";
            this.label_editBZ.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_editBZ.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_editBZ_MouseDown);
            this.label_editBZ.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label_editBZ_MouseMove);
            // 
            // dataGridView_molm_no
            // 
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_molm_no.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridView_molm_no.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_molm_no.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_molm_no.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridView_molm_no.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_molm_no.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView_molm_no.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dataGridView_molm_no.Location = new System.Drawing.Point(213, 39);
            this.dataGridView_molm_no.Name = "dataGridView_molm_no";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_molm_no.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_molm_no.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridView_molm_no.Size = new System.Drawing.Size(190, 85);
            this.dataGridView_molm_no.TabIndex = 19;
            // 
            // dataGridView_reagent_no
            // 
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_reagent_no.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView_reagent_no.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_reagent_no.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_reagent_no.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView_reagent_no.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_reagent_no.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView_reagent_no.Location = new System.Drawing.Point(213, 166);
            this.dataGridView_reagent_no.Name = "dataGridView_reagent_no";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_reagent_no.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_reagent_no.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridView_reagent_no.Size = new System.Drawing.Size(190, 85);
            this.dataGridView_reagent_no.TabIndex = 20;
            // 
            // dataGridView_res_no
            // 
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_res_no.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_res_no.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_res_no.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_res_no.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_res_no.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_res_no.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_res_no.Location = new System.Drawing.Point(213, 293);
            this.dataGridView_res_no.Name = "dataGridView_res_no";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_res_no.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_res_no.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView_res_no.Size = new System.Drawing.Size(190, 85);
            this.dataGridView_res_no.TabIndex = 21;
            // 
            // FormExpertCheck
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 447);
            this.Controls.Add(this.panel_expert);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormExpertCheck";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormExpertCheck";
            this.panel_expert.ResumeLayout(false);
            this.panel_chem_sub.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_res_yes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_reagent_yes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_molm_yes)).EndInit();
            this.panel_text_auth.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_molm_no)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_reagent_no)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_res_no)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_expert;
        private System.Windows.Forms.Button button_check;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Panel panel_chem_sub;
        private System.Windows.Forms.Button button_res;
        private System.Windows.Forms.Button button_reagent;
        private System.Windows.Forms.Button button_reaction;
        private System.Windows.Forms.Button button_mol_m;
        private System.Windows.Forms.Button button_chem_sub;
        private System.Windows.Forms.Panel panel_text_auth;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Label label_editBZ;
        private System.Windows.Forms.DataGridView dataGridView_molm_yes;
        private System.Windows.Forms.DataGridView dataGridView_res_yes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView_reagent_yes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label text1;
        private System.Windows.Forms.DataGridView dataGridView_molm_no;
        private System.Windows.Forms.DataGridView dataGridView_res_no;
        private System.Windows.Forms.DataGridView dataGridView_reagent_no;
    }
}