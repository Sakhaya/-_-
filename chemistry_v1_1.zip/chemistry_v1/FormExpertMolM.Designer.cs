﻿
namespace chemistry_v1
{
    partial class FormExpertMolM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_expert = new System.Windows.Forms.Panel();
            this.button_check = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.panel_mol_m = new System.Windows.Forms.Panel();
            this.button_restart = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.dataGridView_chemSub = new System.Windows.Forms.DataGridView();
            this.text_table = new System.Windows.Forms.Label();
            this.text_chem_sub = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button_res = new System.Windows.Forms.Button();
            this.button_reagent = new System.Windows.Forms.Button();
            this.button_reaction = new System.Windows.Forms.Button();
            this.button_mol_m = new System.Windows.Forms.Button();
            this.button_chem_sub = new System.Windows.Forms.Button();
            this.panel_text_auth = new System.Windows.Forms.Panel();
            this.button_close = new System.Windows.Forms.Button();
            this.label_editBZ = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_mol_m = new System.Windows.Forms.TextBox();
            this.button_add = new System.Windows.Forms.Button();
            this.panel_expert.SuspendLayout();
            this.panel_mol_m.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_chemSub)).BeginInit();
            this.panel_text_auth.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_expert
            // 
            this.panel_expert.BackColor = System.Drawing.SystemColors.Menu;
            this.panel_expert.Controls.Add(this.button_check);
            this.panel_expert.Controls.Add(this.button_exit);
            this.panel_expert.Controls.Add(this.panel_mol_m);
            this.panel_expert.Controls.Add(this.button_res);
            this.panel_expert.Controls.Add(this.button_reagent);
            this.panel_expert.Controls.Add(this.button_reaction);
            this.panel_expert.Controls.Add(this.button_mol_m);
            this.panel_expert.Controls.Add(this.button_chem_sub);
            this.panel_expert.Controls.Add(this.panel_text_auth);
            this.panel_expert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_expert.Location = new System.Drawing.Point(0, 0);
            this.panel_expert.Name = "panel_expert";
            this.panel_expert.Size = new System.Drawing.Size(548, 447);
            this.panel_expert.TabIndex = 2;
            this.panel_expert.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_expert_MouseDown);
            this.panel_expert.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_expert_MouseMove);
            // 
            // button_check
            // 
            this.button_check.BackColor = System.Drawing.Color.ForestGreen;
            this.button_check.FlatAppearance.BorderSize = 0;
            this.button_check.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_check.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_check.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_check.Location = new System.Drawing.Point(0, 357);
            this.button_check.Name = "button_check";
            this.button_check.Size = new System.Drawing.Size(107, 51);
            this.button_check.TabIndex = 10;
            this.button_check.Text = "Проверка полноты знаний ";
            this.button_check.UseVisualStyleBackColor = false;
            this.button_check.Click += new System.EventHandler(this.button_check_Click);
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button_exit.FlatAppearance.BorderSize = 0;
            this.button_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_exit.Location = new System.Drawing.Point(0, 414);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(107, 21);
            this.button_exit.TabIndex = 9;
            this.button_exit.Text = "Выйти";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // panel_mol_m
            // 
            this.panel_mol_m.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_mol_m.Controls.Add(this.button_add);
            this.panel_mol_m.Controls.Add(this.textBox_mol_m);
            this.panel_mol_m.Controls.Add(this.label1);
            this.panel_mol_m.Controls.Add(this.button_restart);
            this.panel_mol_m.Controls.Add(this.button_delete);
            this.panel_mol_m.Controls.Add(this.dataGridView_chemSub);
            this.panel_mol_m.Controls.Add(this.text_table);
            this.panel_mol_m.Controls.Add(this.text_chem_sub);
            this.panel_mol_m.Controls.Add(this.listBox1);
            this.panel_mol_m.Location = new System.Drawing.Point(113, 37);
            this.panel_mol_m.Name = "panel_mol_m";
            this.panel_mol_m.Size = new System.Drawing.Size(423, 398);
            this.panel_mol_m.TabIndex = 8;
            // 
            // button_restart
            // 
            this.button_restart.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_restart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_restart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_restart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_restart.Location = new System.Drawing.Point(217, 368);
            this.button_restart.Name = "button_restart";
            this.button_restart.Size = new System.Drawing.Size(89, 22);
            this.button_restart.TabIndex = 14;
            this.button_restart.Text = "Обновить";
            this.button_restart.UseVisualStyleBackColor = false;
            this.button_restart.Click += new System.EventHandler(this.button_restart_Click);
            // 
            // button_delete
            // 
            this.button_delete.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_delete.Location = new System.Drawing.Point(312, 368);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(89, 22);
            this.button_delete.TabIndex = 13;
            this.button_delete.Text = "Удалить";
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // dataGridView_chemSub
            // 
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_chemSub.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle41;
            this.dataGridView_chemSub.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_chemSub.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_chemSub.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.dataGridView_chemSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_chemSub.DefaultCellStyle = dataGridViewCellStyle43;
            this.dataGridView_chemSub.Location = new System.Drawing.Point(15, 193);
            this.dataGridView_chemSub.Name = "dataGridView_chemSub";
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_chemSub.RowHeadersDefaultCellStyle = dataGridViewCellStyle44;
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_chemSub.RowsDefaultCellStyle = dataGridViewCellStyle45;
            this.dataGridView_chemSub.Size = new System.Drawing.Size(387, 166);
            this.dataGridView_chemSub.TabIndex = 12;
            // 
            // text_table
            // 
            this.text_table.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.text_table.Location = new System.Drawing.Point(0, 154);
            this.text_table.Name = "text_table";
            this.text_table.Size = new System.Drawing.Size(419, 36);
            this.text_table.TabIndex = 11;
            this.text_table.Text = "Список химических веществ  ";
            this.text_table.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_chem_sub
            // 
            this.text_chem_sub.Dock = System.Windows.Forms.DockStyle.Top;
            this.text_chem_sub.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.text_chem_sub.Location = new System.Drawing.Point(0, 0);
            this.text_chem_sub.Name = "text_chem_sub";
            this.text_chem_sub.Size = new System.Drawing.Size(419, 36);
            this.text_chem_sub.TabIndex = 10;
            this.text_chem_sub.Text = "Выберите химическое вещество ";
            this.text_chem_sub.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(15, 39);
            this.listBox1.Name = "listBox1";
            this.listBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBox1.ScrollAlwaysVisible = true;
            this.listBox1.Size = new System.Drawing.Size(386, 24);
            this.listBox1.TabIndex = 0;
            this.listBox1.TabStop = false;
            // 
            // button_res
            // 
            this.button_res.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_res.FlatAppearance.BorderSize = 0;
            this.button_res.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_res.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_res.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_res.Location = new System.Drawing.Point(0, 213);
            this.button_res.Name = "button_res";
            this.button_res.Size = new System.Drawing.Size(107, 38);
            this.button_res.TabIndex = 7;
            this.button_res.Text = "Результаты ";
            this.button_res.UseVisualStyleBackColor = false;
            this.button_res.Click += new System.EventHandler(this.button_res_Click);
            // 
            // button_reagent
            // 
            this.button_reagent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_reagent.FlatAppearance.BorderSize = 0;
            this.button_reagent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reagent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_reagent.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_reagent.Location = new System.Drawing.Point(0, 169);
            this.button_reagent.Name = "button_reagent";
            this.button_reagent.Size = new System.Drawing.Size(107, 38);
            this.button_reagent.TabIndex = 6;
            this.button_reagent.Text = "Реагенты";
            this.button_reagent.UseVisualStyleBackColor = false;
            this.button_reagent.Click += new System.EventHandler(this.button_reagent_Click);
            // 
            // button_reaction
            // 
            this.button_reaction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_reaction.FlatAppearance.BorderSize = 0;
            this.button_reaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_reaction.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_reaction.Location = new System.Drawing.Point(0, 125);
            this.button_reaction.Name = "button_reaction";
            this.button_reaction.Size = new System.Drawing.Size(107, 38);
            this.button_reaction.TabIndex = 5;
            this.button_reaction.Text = "Реакции";
            this.button_reaction.UseVisualStyleBackColor = false;
            this.button_reaction.Click += new System.EventHandler(this.button_reaction_Click);
            // 
            // button_mol_m
            // 
            this.button_mol_m.BackColor = System.Drawing.SystemColors.Highlight;
            this.button_mol_m.FlatAppearance.BorderSize = 0;
            this.button_mol_m.FlatAppearance.MouseDownBackColor = System.Drawing.SystemColors.Highlight;
            this.button_mol_m.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Highlight;
            this.button_mol_m.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mol_m.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_mol_m.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_mol_m.Location = new System.Drawing.Point(0, 81);
            this.button_mol_m.Name = "button_mol_m";
            this.button_mol_m.Size = new System.Drawing.Size(113, 38);
            this.button_mol_m.TabIndex = 4;
            this.button_mol_m.Text = "Молярная масса";
            this.button_mol_m.UseVisualStyleBackColor = false;
            // 
            // button_chem_sub
            // 
            this.button_chem_sub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_chem_sub.FlatAppearance.BorderSize = 0;
            this.button_chem_sub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_chem_sub.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_chem_sub.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_chem_sub.Location = new System.Drawing.Point(0, 37);
            this.button_chem_sub.Name = "button_chem_sub";
            this.button_chem_sub.Size = new System.Drawing.Size(107, 38);
            this.button_chem_sub.TabIndex = 3;
            this.button_chem_sub.Text = "Химические вещества";
            this.button_chem_sub.UseVisualStyleBackColor = false;
            this.button_chem_sub.Click += new System.EventHandler(this.button_chem_sub_Click);
            // 
            // panel_text_auth
            // 
            this.panel_text_auth.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_text_auth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_text_auth.Controls.Add(this.button_close);
            this.panel_text_auth.Controls.Add(this.label_editBZ);
            this.panel_text_auth.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_text_auth.Location = new System.Drawing.Point(0, 0);
            this.panel_text_auth.Name = "panel_text_auth";
            this.panel_text_auth.Size = new System.Drawing.Size(548, 31);
            this.panel_text_auth.TabIndex = 2;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Red;
            this.button_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_close.FlatAppearance.BorderSize = 0;
            this.button_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_close.Location = new System.Drawing.Point(525, -1);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(22, 20);
            this.button_close.TabIndex = 1;
            this.button_close.Text = "X";
            this.button_close.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.button_close.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button_close.UseVisualStyleBackColor = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // label_editBZ
            // 
            this.label_editBZ.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label_editBZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_editBZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_editBZ.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label_editBZ.Location = new System.Drawing.Point(0, 0);
            this.label_editBZ.Name = "label_editBZ";
            this.label_editBZ.Size = new System.Drawing.Size(546, 29);
            this.label_editBZ.TabIndex = 0;
            this.label_editBZ.Text = "Редактор базы знаний";
            this.label_editBZ.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_editBZ.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_editBZ_MouseDown);
            this.label_editBZ.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label_editBZ_MouseMove);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(2, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(419, 36);
            this.label1.TabIndex = 15;
            this.label1.Text = "Введите молярную массу вещества";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox_mol_m
            // 
            this.textBox_mol_m.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_mol_m.Location = new System.Drawing.Point(15, 113);
            this.textBox_mol_m.Multiline = true;
            this.textBox_mol_m.Name = "textBox_mol_m";
            this.textBox_mol_m.Size = new System.Drawing.Size(291, 35);
            this.textBox_mol_m.TabIndex = 16;
            this.textBox_mol_m.Enter += new System.EventHandler(this.textBox_mol_m_Enter);
            // 
            // button_add
            // 
            this.button_add.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_add.Location = new System.Drawing.Point(311, 113);
            this.button_add.Margin = new System.Windows.Forms.Padding(0);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(91, 35);
            this.button_add.TabIndex = 17;
            this.button_add.Text = "Добавить";
            this.button_add.UseVisualStyleBackColor = false;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // FormExpertMolM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 447);
            this.Controls.Add(this.panel_expert);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormExpertMolM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormExpertMolM";
            this.panel_expert.ResumeLayout(false);
            this.panel_mol_m.ResumeLayout(false);
            this.panel_mol_m.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_chemSub)).EndInit();
            this.panel_text_auth.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_expert;
        private System.Windows.Forms.Button button_check;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Panel panel_mol_m;
        private System.Windows.Forms.Button button_res;
        private System.Windows.Forms.Button button_reagent;
        private System.Windows.Forms.Button button_reaction;
        private System.Windows.Forms.Button button_mol_m;
        private System.Windows.Forms.Button button_chem_sub;
        private System.Windows.Forms.Panel panel_text_auth;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Label label_editBZ;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button_restart;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.DataGridView dataGridView_chemSub;
        private System.Windows.Forms.Label text_table;
        private System.Windows.Forms.Label text_chem_sub;
        private System.Windows.Forms.TextBox textBox_mol_m;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_add;
    }
}