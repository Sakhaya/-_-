﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chemistry_v1
{
    public partial class FormExpertMolM : Form
    {
        public FormExpertMolM()
        {
            InitializeComponent();

            textBox_mol_m.Text = "Введите молярную массу химического вещества";
            textBox_mol_m.ForeColor = Color.Gray;

            FillList();
            ShowTable();
        }

        public void FillList()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `name_chem` FROM `chem_sub`", db.getConnection());


            db.openConnecntion();
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                listBox1.Items.Add(reader["name_chem"].ToString());
            }

            reader.Close();
            db.closeConnecntion();

        }

        public void ShowTable()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `chem_sub`.`name_chem`, `mol_m`.`m` FROM `chem_sub` JOIN `mol_m` ON `mol_m`.`id_chem` = `chem_sub`.`id_chem`;", db.getConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView_chemSub.DataSource = table;
        }

        public Boolean isNameExist()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `chem_sub`.`name_chem`, `mol_m`.`m` FROM `chem_sub` JOIN `mol_m` ON `mol_m`.`id_chem` = `chem_sub`.`id_chem` WHERE `chem_sub`.`name_chem` = @nameSub", db.getConnection());
            command.Parameters.Add("@nameSub", MySqlDbType.VarChar).Value = listBox1.SelectedItem;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Моляраная масса с этим элементом уже существует!");
                return true;
            }
            else
            {
                return false;
            }
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            authorization autho = new authorization();
            autho.Show();
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        Point lastPoint;
        private void panel_expert_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel_expert_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void label_editBZ_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void label_editBZ_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void button_chem_sub_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpert chem_sub = new FormExpert();
            chem_sub.Show();
        }

        private void button_reaction_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertReaction reaction = new FormExpertReaction();
            reaction.Show();
        }

        private void button_reagent_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertReagent reagent = new FormExpertReagent();
            reagent.Show();
        }

        private void button_res_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertRes form = new FormExpertRes();
            form.Show();
        }

        private void button_check_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertCheck form = new FormExpertCheck();
            form.Show();
        }

        private void button_restart_Click(object sender, EventArgs e)
        {
            ShowTable();
        }

        public int ShareId(object nameSub)
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `id_chem` FROM `chem_sub` WHERE `name_chem` = @nameSub", db.getConnection());

            command.Parameters.Add("@nameSub", MySqlDbType.VarChar).Value = nameSub.ToString();

            int id = 0;

            db.openConnecntion();

            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    id = Convert.ToInt32(reader["id_chem"]);
                }
            }

            db.closeConnecntion();

            return id;
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите химическое вещество!");
                return;
            }
            if (textBox_mol_m.Text == "Введите молярную массу химического вещества")
            {
                MessageBox.Show("Введите молярную массу!");
                return;
            }

            if (isNameExist())
            {
                return;
            }

            DB db = new DB();
            MySqlCommand command = new MySqlCommand("INSERT INTO `mol_m` (`id_chem`, `m`) VALUES (@idSub, @m)", db.getConnection());

            command.Parameters.Add("@m", MySqlDbType.Int32).Value = textBox_mol_m.Text;
            command.Parameters.Add("@idSub", MySqlDbType.Int32).Value = ShareId(listBox1.SelectedItem);

            db.openConnecntion();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Молярная масса вещества добавлена.");
                ShowTable();
                textBox_mol_m.Text = "Введите молярную массу химического вещества";
                textBox_mol_m.ForeColor = Color.Gray;
            }
            else
            {
                MessageBox.Show("Молярная масса вещества не добавлена.");
            }

            db.closeConnecntion();
        }

        private void textBox_mol_m_Enter(object sender, EventArgs e)
        {
            if (textBox_mol_m.Text == "Введите молярную массу химического вещества")
            {
                textBox_mol_m.Text = "";
                textBox_mol_m.ForeColor = Color.Black;
            }
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            if (dataGridView_chemSub.SelectedRows.Count > 0)
            {
                DB db = new DB();
                MySqlCommand command = new MySqlCommand("DELETE FROM mol_m WHERE id_chem = @idSub", db.getConnection());
                DataGridViewRow row = new DataGridViewRow();
                row = dataGridView_chemSub.SelectedRows[0];
                command.Parameters.Add("@idSub", MySqlDbType.Int32).Value = ShareId(row.Cells[0].Value.ToString());

                db.openConnecntion();
                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Молярная масса удалена.");
                    ShowTable();
                }
                else
                {
                    MessageBox.Show("Молярная масса не удалена.");
                }
                db.closeConnecntion();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку!");
            }
        }
    }
}
