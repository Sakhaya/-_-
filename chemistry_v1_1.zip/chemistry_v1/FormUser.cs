﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chemistry_v1
{
    public partial class FormUser : Form
    {
        public FormUser()
        {
            InitializeComponent();
            FillList();
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void FillList()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `name_chem` FROM `chem_sub`", db.getConnection());


            db.openConnecntion();
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                listBox_sub.Items.Add(reader["name_chem"].ToString());
                listBox_res.Items.Add(reader["name_chem"].ToString());
            }

            reader.Close();
            db.closeConnecntion();

        }

        private void button_add_sub_Click(object sender, EventArgs e)
        {
            // Получение ссылки на DataTable, который используется как источник данных для DataGridView
            DataTable table;
            if (dataGridView_chemSub.DataSource == null)
            {
                // Создание и настройка DataTable, если он ещё не был инициализирован.
                table = new DataTable();
                table.Columns.Add("Chem_cub", typeof(string)); // Или другой подходящий тип данных
                dataGridView_chemSub.DataSource = table;
            }
            else
            {
                table = (DataTable)dataGridView_chemSub.DataSource;
            }

            // Перебор всех выбранных элементов в ListBox (предполагая, что множественный выбор возможен)
            foreach (var item in listBox_sub.SelectedItems)
            {
                // Добавление строки в таблицу. Преобразование элемента к строке, если нужно.
                table.Rows.Add(item.ToString());
            }

            // Если ничего не выбрано, предупреждаем пользователя
            if (listBox_sub.SelectedItems.Count == 0)
            {
                MessageBox.Show("Пожалуйста, выберите элемент(ы) из списка.");
            }

            // Присваивание DataTable в качестве источника данных для DataGridView
            dataGridView_chemSub.DataSource = table;
        }

        private void button_add_res_Click(object sender, EventArgs e)
        {
            // Получение ссылки на DataTable, который используется как источник данных для DataGridView
            DataTable table;
            if (dataGridView_res.DataSource == null)
            {
                // Создание и настройка DataTable, если он ещё не был инициализирован.
                table = new DataTable();
                table.Columns.Add("Res_sub", typeof(string)); // Или другой подходящий тип данных
                dataGridView_res.DataSource = table;
            }
            else
            {
                table = (DataTable)dataGridView_res.DataSource;
            }

            // Перебор всех выбранных элементов в ListBox (предполагая, что множественный выбор возможен)
            foreach (var item in listBox_res.SelectedItems)
            {
                // Добавление строки в таблицу. Преобразование элемента к строке, если нужно.
                table.Rows.Add(item.ToString());
            }

            // Если ничего не выбрано, предупреждаем пользователя
            if (listBox_res.SelectedItems.Count == 0)
            {
                MessageBox.Show("Пожалуйста, выберите элемент(ы) из списка.");
            }

            // Присваивание DataTable в качестве источника данных для DataGridView
            dataGridView_res.DataSource = table;
        }

        private void button_add_molm_Click(object sender, EventArgs e)
        {
            // Получение ссылки на DataTable, который используется как источник данных для DataGridView
            DataTable table;
            if (dataGridView_molm.DataSource == null)
            {
                // Создание и настройка DataTable, если он ещё не был инициализирован.
                table = new DataTable();
                table.Columns.Add("Mass", typeof(string)); // Или другой подходящий тип данных
                dataGridView_molm.DataSource = table;
            }
            else
            {
                table = (DataTable)dataGridView_molm.DataSource;
            }

            // Проверка, что текстовое поле не пустое
            if (!string.IsNullOrWhiteSpace(textBox_molm.Text))
            {
                // Добавление новой строки в DataTable
                var newRow = table.NewRow();
                newRow["Mass"] = textBox_molm.Text; // Указываем значение из текстового поля
                table.Rows.Add(newRow);

                // Очистка текстового поля после добавления строки (опционально)
                textBox_molm.Text = "";
            }
            else
            {
                // Сообщение пользователю, если текстовое поле пустое
                MessageBox.Show("Пожалуйста, введите молярную массу.");
            }
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            authorization autho = new authorization();
            autho.Show();
        }

        private void button_cleanAll_Click(object sender, EventArgs e)
        {
            // Проверка, использует ли DataGridView DataTable в качестве DataSource
            if (dataGridView_chemSub.DataSource is DataTable)
            {
                // Очистка всех строк DataTable
                ((DataTable)dataGridView_chemSub.DataSource).Rows.Clear();
            }
            else
            {
                // Просто обнуление DataSource, если это не DataTable
                dataGridView_chemSub.DataSource = null;
            }

            // Проверка, использует ли DataGridView DataTable в качестве DataSource
            if (dataGridView_molm.DataSource is DataTable)
            {
                // Очистка всех строк DataTable
                ((DataTable)dataGridView_molm.DataSource).Rows.Clear();
            }
            else
            {
                // Просто обнуление DataSource, если это не DataTable
                dataGridView_molm.DataSource = null;
            }

            // Проверка, использует ли DataGridView DataTable в качестве DataSource
            if (dataGridView_res.DataSource is DataTable)
            {
                // Очистка всех строк DataTable
                ((DataTable)dataGridView_res.DataSource).Rows.Clear();
            }
            else
            {
                // Просто обнуление DataSource, если это не DataTable
                dataGridView_res.DataSource = null;
            }
        }

        private void button_start_Click(object sender, EventArgs e)
        {
            int count_sub = dataGridView_chemSub.DisplayedRowCount(false) - 1;
            int count_molm = dataGridView_molm.DisplayedRowCount(false) - 1;

            if (count_sub == count_molm)
            {
                MessageBox.Show("Все верно!");
                MessageBox.Show(count_sub.ToString());
            }
            else
            {
                MessageBox.Show("Введите одинаковое количество химических веществ и начальных масс веществ!");
            }
        }
    }
}
