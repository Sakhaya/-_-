﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chemistry_v1
{
    public partial class FormExpertReaction : Form
    {
        public FormExpertReaction()
        {
            InitializeComponent();

            textBox_name_reaction.Text = "Введите название химической реакции";
            textBox_name_reaction.ForeColor = Color.Gray;

            ShowTable();

        }

        public void ShowTable()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `name_reaction` FROM `reaction`", db.getConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView_reaction.DataSource = table;
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button_chem_sub_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpert chem_sub = new FormExpert();
            chem_sub.Show();
        }

        private void button_mol_m_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertMolM molm = new FormExpertMolM();
            molm.Show();
        }
        Point lastPoint;

        private void panel_expert_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel_expert_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void label_editBZ_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void label_editBZ_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            authorization autho = new authorization();
            autho.Show();
        }

        private void button_reagent_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertReagent reagent = new FormExpertReagent();
            reagent.Show();
        }

        private void button_res_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertRes form = new FormExpertRes();
            form.Show();
        }

        private void button_check_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertCheck form = new FormExpertCheck();
            form.Show();
        }

        private void textBox_name_reaction_Enter(object sender, EventArgs e)
        {
            if (textBox_name_reaction.Text == "Введите название химической реакции")
            {
                textBox_name_reaction.Text = "";
                textBox_name_reaction.ForeColor = Color.Black;
            }
        }

        public Boolean isNameExist()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `reaction` WHERE `name_reaction` = @nameReaction", db.getConnection());
            command.Parameters.Add("@nameReaction", MySqlDbType.VarChar).Value = textBox_name_reaction.Text;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Такое название уже существует!");
                return true;
            }
            else
            {
                return false;
            }
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            if (textBox_name_reaction.Text == "Введите название химической реакции")
            {
                MessageBox.Show("Введите название!");
                return;
            }

            if (isNameExist())
            {
                return;
            }

            DB db = new DB();
            MySqlCommand command = new MySqlCommand("INSERT INTO `reaction` (`name_reaction`) VALUES (@nameReaction)", db.getConnection());

            command.Parameters.Add("@nameReaction", MySqlDbType.VarChar).Value = textBox_name_reaction.Text;

            db.openConnecntion();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Химическая реакция добавлена.");
                ShowTable();
                textBox_name_reaction.Text = "Введите название химической реакции";
                textBox_name_reaction.ForeColor = Color.Gray;
            }
            else
            {
                MessageBox.Show("Химическая реакция не добавлена.");
            }

            db.closeConnecntion();
        }

        private void textBox_name_reaction_Leave(object sender, EventArgs e)
        {
            if (textBox_name_reaction.Text == "")
            {
                textBox_name_reaction.Text = "Введите название химического вещества";
                textBox_name_reaction.ForeColor = Color.Gray;
            }
        }

        private void button_restart_Click(object sender, EventArgs e)
        {
            ShowTable();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            if (dataGridView_reaction.SelectedRows.Count > 0)
            {
                DB db = new DB();
                MySqlCommand command = new MySqlCommand("DELETE FROM reaction WHERE name_reaction = @nameReaction", db.getConnection());
                DataGridViewRow row = new DataGridViewRow();
                row = dataGridView_reaction.SelectedRows[0];
                command.Parameters.Add("@nameReaction", MySqlDbType.VarChar).Value = row.Cells[0].Value.ToString();

                db.openConnecntion();
                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Химическая реакция удалена.");
                    ShowTable();
                }
                else
                {
                    MessageBox.Show("Химическая реакция не удалена.");
                }
                db.closeConnecntion();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку!");
            }
        }
    }
}
