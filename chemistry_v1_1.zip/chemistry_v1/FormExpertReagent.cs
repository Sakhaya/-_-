﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chemistry_v1
{
    public partial class FormExpertReagent : Form
    {
        public FormExpertReagent()
        {
            InitializeComponent();
            FillList_sub();
            FillList_reaction();
            ShowTable();
        }

        public void FillList_sub()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `name_chem` FROM `chem_sub`", db.getConnection());


            db.openConnecntion();
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                listBox_reagent1.Items.Add(reader["name_chem"].ToString());
                listBox_reagent2.Items.Add(reader["name_chem"].ToString());
            }

            reader.Close();
            db.closeConnecntion();

        }

        public void FillList_reaction()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `name_reaction` FROM `reaction`", db.getConnection());


            db.openConnecntion();
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                listBox_reaction.Items.Add(reader["name_reaction"].ToString());
            }

            reader.Close();
            db.closeConnecntion();

        }

        public void ShowTable()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `reaction`.`name_reaction`, `reagent`.`sub1_name`,  `reagent`.`sub2_name` FROM `reaction` JOIN `reagent` ON `reagent`.`id_reaction` = `reaction`.`id_reaction`; ", db.getConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView_reagent.DataSource = table;
        }

        public Boolean isNameExist()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `reaction` JOIN `reagent` ON `reagent`.`id_reaction` = `reaction`.`id_reaction` WHERE `reaction`.`name_reaction` = @nameReaction", db.getConnection());
            command.Parameters.Add("@nameReaction", MySqlDbType.VarChar).Value = listBox_reaction.SelectedItem;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Реагент с этой реакцией уже существует!");
                return true;
            }
            else
            {
                return false;
            }
        }

        public int ShareId(object nameSub)
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `id_chem` FROM `chem_sub` WHERE `name_chem` = @nameSub", db.getConnection());

            command.Parameters.Add("@nameSub", MySqlDbType.VarChar).Value = nameSub.ToString();

            int id = 0;

            db.openConnecntion();

            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    id = Convert.ToInt32(reader["id_chem"]);
                }
            }

            db.closeConnecntion();

            return id;
        }

        public int ShareId_R(object name_reaction)
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `id_reaction` FROM `reaction` WHERE `name_reaction` = @name_reaction", db.getConnection());

            command.Parameters.Add("@name_reaction", MySqlDbType.VarChar).Value = name_reaction.ToString();

            int id = 0;

            db.openConnecntion();

            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    id = Convert.ToInt32(reader["id_reaction"]);
                }
            }

            db.closeConnecntion();

            return id;
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button_chem_sub_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpert formExpert = new FormExpert();
            formExpert.Show();
        }

        private void button_mol_m_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertMolM molm = new FormExpertMolM();
            molm.Show();
        }

        private void button_reaction_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertReaction reaction = new FormExpertReaction();
            reaction.Show();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            authorization autho = new authorization();
            autho.Show();
        }
        Point lastPoint;
        private void panel_expert_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel_expert_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void label_editBZ_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void label_editBZ_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void button_res_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertRes form = new FormExpertRes();
            form.Show();
        }

        private void button_check_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertCheck form = new FormExpertCheck();
            form.Show();
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            if ((listBox_reaction.SelectedIndex == -1)|| (listBox_reagent1.SelectedIndex == -1)|| (listBox_reagent2.SelectedIndex == -1))
            {
                MessageBox.Show("Выберите все элементы!");
                return;
            }

            if (isNameExist())
            {
                return;
            }

            DB db = new DB();
            MySqlCommand command = new MySqlCommand("INSERT INTO `reagent` (`id_reaction`,`sub1_id`,`sub1_name`, `sub2_id`, `sub2_name`) VALUES (@idReaction, @idSub1, @idSub1_name, @idSub2, @idSub2_name)", db.getConnection());

            command.Parameters.Add("@idReaction", MySqlDbType.Int32).Value = ShareId_R(listBox_reaction.SelectedItem);
            command.Parameters.Add("@idSub1", MySqlDbType.Int32).Value = ShareId(listBox_reagent1.SelectedItem);
            command.Parameters.Add("@idSub1_name", MySqlDbType.VarChar).Value = listBox_reagent1.SelectedItem;
            command.Parameters.Add("@idSub2", MySqlDbType.Int32).Value = ShareId(listBox_reagent2.SelectedItem);
            command.Parameters.Add("@idSub2_name", MySqlDbType.VarChar).Value = listBox_reagent2.SelectedItem;


            db.openConnecntion();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Новый реагент добавлен.");
                ShowTable();
            }
            else
            {
                MessageBox.Show("Реагент не добавлен.");
            }

            db.closeConnecntion();
        }

        private void button_restart_Click(object sender, EventArgs e)
        {
            ShowTable();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            if (dataGridView_reagent.SelectedRows.Count > 0)
            {
                DB db = new DB();
                MySqlCommand command = new MySqlCommand("DELETE FROM reagent WHERE id_reaction = @idReaction", db.getConnection());
                DataGridViewRow row = new DataGridViewRow();
                row = dataGridView_reagent.SelectedRows[0];
                command.Parameters.Add("@idReaction", MySqlDbType.Int32).Value = ShareId_R(row.Cells[0].Value.ToString());

                db.openConnecntion();
                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Реагент удален.");
                    ShowTable();
                }
                else
                {
                    MessageBox.Show("Реагент не удален.");
                }
                db.closeConnecntion();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку!");
            }
        }
    }
}
