﻿
namespace chemistry_v1
{
    partial class FormUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label_user1 = new System.Windows.Forms.Label();
            this.panel_user = new System.Windows.Forms.Panel();
            this.button_cleanAll = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.button_start = new System.Windows.Forms.Button();
            this.dataGridView_res = new System.Windows.Forms.DataGridView();
            this.dataGridView_molm = new System.Windows.Forms.DataGridView();
            this.dataGridView_chemSub = new System.Windows.Forms.DataGridView();
            this.button_add_res = new System.Windows.Forms.Button();
            this.button_add_molm = new System.Windows.Forms.Button();
            this.button_add_sub = new System.Windows.Forms.Button();
            this.listBox_res = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_molm = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox_sub = new System.Windows.Forms.ListBox();
            this.panel_text_auth = new System.Windows.Forms.Panel();
            this.button_close = new System.Windows.Forms.Button();
            this.panel_user.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_res)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_molm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_chemSub)).BeginInit();
            this.panel_text_auth.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_user1
            // 
            this.label_user1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label_user1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_user1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_user1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label_user1.Location = new System.Drawing.Point(0, 0);
            this.label_user1.Name = "label_user1";
            this.label_user1.Size = new System.Drawing.Size(547, 29);
            this.label_user1.TabIndex = 0;
            this.label_user1.Text = "Ввод исходных данных";
            this.label_user1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_user
            // 
            this.panel_user.BackColor = System.Drawing.SystemColors.Menu;
            this.panel_user.Controls.Add(this.button_cleanAll);
            this.panel_user.Controls.Add(this.button_exit);
            this.panel_user.Controls.Add(this.button_start);
            this.panel_user.Controls.Add(this.dataGridView_res);
            this.panel_user.Controls.Add(this.dataGridView_molm);
            this.panel_user.Controls.Add(this.dataGridView_chemSub);
            this.panel_user.Controls.Add(this.button_add_res);
            this.panel_user.Controls.Add(this.button_add_molm);
            this.panel_user.Controls.Add(this.button_add_sub);
            this.panel_user.Controls.Add(this.listBox_res);
            this.panel_user.Controls.Add(this.label3);
            this.panel_user.Controls.Add(this.textBox_molm);
            this.panel_user.Controls.Add(this.label2);
            this.panel_user.Controls.Add(this.label1);
            this.panel_user.Controls.Add(this.listBox_sub);
            this.panel_user.Controls.Add(this.panel_text_auth);
            this.panel_user.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_user.Location = new System.Drawing.Point(0, 0);
            this.panel_user.Name = "panel_user";
            this.panel_user.Size = new System.Drawing.Size(549, 387);
            this.panel_user.TabIndex = 2;
            // 
            // button_cleanAll
            // 
            this.button_cleanAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button_cleanAll.FlatAppearance.BorderSize = 0;
            this.button_cleanAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_cleanAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_cleanAll.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_cleanAll.Location = new System.Drawing.Point(430, 357);
            this.button_cleanAll.Name = "button_cleanAll";
            this.button_cleanAll.Size = new System.Drawing.Size(107, 21);
            this.button_cleanAll.TabIndex = 17;
            this.button_cleanAll.Text = "Очистить";
            this.button_cleanAll.UseVisualStyleBackColor = false;
            this.button_cleanAll.Click += new System.EventHandler(this.button_cleanAll_Click);
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button_exit.FlatAppearance.BorderSize = 0;
            this.button_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_exit.Location = new System.Drawing.Point(12, 357);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(107, 21);
            this.button_exit.TabIndex = 16;
            this.button_exit.Text = "Выйти";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_start
            // 
            this.button_start.BackColor = System.Drawing.Color.Green;
            this.button_start.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_start.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_start.Location = new System.Drawing.Point(191, 343);
            this.button_start.Margin = new System.Windows.Forms.Padding(0);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(166, 35);
            this.button_start.TabIndex = 15;
            this.button_start.Text = "Готово";
            this.button_start.UseVisualStyleBackColor = false;
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            // 
            // dataGridView_res
            // 
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_res.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle46;
            this.dataGridView_res.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_res.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_res.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle47;
            this.dataGridView_res.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_res.DefaultCellStyle = dataGridViewCellStyle48;
            this.dataGridView_res.Location = new System.Drawing.Point(392, 145);
            this.dataGridView_res.Name = "dataGridView_res";
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle49.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle49.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_res.RowHeadersDefaultCellStyle = dataGridViewCellStyle49;
            dataGridViewCellStyle50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_res.RowsDefaultCellStyle = dataGridViewCellStyle50;
            this.dataGridView_res.Size = new System.Drawing.Size(145, 192);
            this.dataGridView_res.TabIndex = 14;
            // 
            // dataGridView_molm
            // 
            dataGridViewCellStyle51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_molm.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle51;
            this.dataGridView_molm.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_molm.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle52.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle52.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle52.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle52.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle52.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_molm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle52;
            this.dataGridView_molm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle53.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle53.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle53.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle53.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle53.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_molm.DefaultCellStyle = dataGridViewCellStyle53;
            this.dataGridView_molm.Location = new System.Drawing.Point(191, 145);
            this.dataGridView_molm.Name = "dataGridView_molm";
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle54.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle54.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle54.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_molm.RowHeadersDefaultCellStyle = dataGridViewCellStyle54;
            dataGridViewCellStyle55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_molm.RowsDefaultCellStyle = dataGridViewCellStyle55;
            this.dataGridView_molm.Size = new System.Drawing.Size(166, 192);
            this.dataGridView_molm.TabIndex = 13;
            // 
            // dataGridView_chemSub
            // 
            dataGridViewCellStyle56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_chemSub.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle56;
            this.dataGridView_chemSub.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_chemSub.BackgroundColor = System.Drawing.SystemColors.ScrollBar;
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle57.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle57.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle57.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle57.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_chemSub.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle57;
            this.dataGridView_chemSub.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle58.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle58.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle58.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle58.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle58.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView_chemSub.DefaultCellStyle = dataGridViewCellStyle58;
            this.dataGridView_chemSub.Location = new System.Drawing.Point(12, 145);
            this.dataGridView_chemSub.Name = "dataGridView_chemSub";
            dataGridViewCellStyle59.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle59.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle59.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle59.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle59.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle59.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle59.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView_chemSub.RowHeadersDefaultCellStyle = dataGridViewCellStyle59;
            dataGridViewCellStyle60.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dataGridView_chemSub.RowsDefaultCellStyle = dataGridViewCellStyle60;
            this.dataGridView_chemSub.Size = new System.Drawing.Size(145, 192);
            this.dataGridView_chemSub.TabIndex = 12;
            // 
            // button_add_res
            // 
            this.button_add_res.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_add_res.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add_res.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_add_res.Location = new System.Drawing.Point(392, 118);
            this.button_add_res.Margin = new System.Windows.Forms.Padding(0);
            this.button_add_res.Name = "button_add_res";
            this.button_add_res.Size = new System.Drawing.Size(145, 24);
            this.button_add_res.TabIndex = 11;
            this.button_add_res.Text = "Добавить";
            this.button_add_res.UseVisualStyleBackColor = false;
            this.button_add_res.Click += new System.EventHandler(this.button_add_res_Click);
            // 
            // button_add_molm
            // 
            this.button_add_molm.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_add_molm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add_molm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_add_molm.Location = new System.Drawing.Point(191, 118);
            this.button_add_molm.Margin = new System.Windows.Forms.Padding(0);
            this.button_add_molm.Name = "button_add_molm";
            this.button_add_molm.Size = new System.Drawing.Size(166, 24);
            this.button_add_molm.TabIndex = 10;
            this.button_add_molm.Text = "Добавить";
            this.button_add_molm.UseVisualStyleBackColor = false;
            this.button_add_molm.Click += new System.EventHandler(this.button_add_molm_Click);
            // 
            // button_add_sub
            // 
            this.button_add_sub.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button_add_sub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add_sub.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_add_sub.Location = new System.Drawing.Point(12, 118);
            this.button_add_sub.Margin = new System.Windows.Forms.Padding(0);
            this.button_add_sub.Name = "button_add_sub";
            this.button_add_sub.Size = new System.Drawing.Size(145, 24);
            this.button_add_sub.TabIndex = 9;
            this.button_add_sub.Text = "Добавить";
            this.button_add_sub.UseVisualStyleBackColor = false;
            this.button_add_sub.Click += new System.EventHandler(this.button_add_sub_Click);
            // 
            // listBox_res
            // 
            this.listBox_res.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBox_res.FormattingEnabled = true;
            this.listBox_res.ItemHeight = 20;
            this.listBox_res.Location = new System.Drawing.Point(392, 91);
            this.listBox_res.Name = "listBox_res";
            this.listBox_res.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBox_res.ScrollAlwaysVisible = true;
            this.listBox_res.Size = new System.Drawing.Size(145, 24);
            this.listBox_res.TabIndex = 8;
            this.listBox_res.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(417, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Результат";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBox_molm
            // 
            this.textBox_molm.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_molm.Location = new System.Drawing.Point(191, 91);
            this.textBox_molm.Multiline = true;
            this.textBox_molm.Name = "textBox_molm";
            this.textBox_molm.Size = new System.Drawing.Size(166, 24);
            this.textBox_molm.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(229, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 54);
            this.label2.TabIndex = 5;
            this.label2.Text = "Начальная\r\nмасса\r\nвеществ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(35, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 54);
            this.label1.TabIndex = 4;
            this.label1.Text = "Начальные \r\nхимические \r\nвещества";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // listBox_sub
            // 
            this.listBox_sub.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.listBox_sub.FormattingEnabled = true;
            this.listBox_sub.ItemHeight = 20;
            this.listBox_sub.Location = new System.Drawing.Point(12, 91);
            this.listBox_sub.Name = "listBox_sub";
            this.listBox_sub.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBox_sub.ScrollAlwaysVisible = true;
            this.listBox_sub.Size = new System.Drawing.Size(145, 24);
            this.listBox_sub.TabIndex = 3;
            this.listBox_sub.TabStop = false;
            // 
            // panel_text_auth
            // 
            this.panel_text_auth.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_text_auth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_text_auth.Controls.Add(this.button_close);
            this.panel_text_auth.Controls.Add(this.label_user1);
            this.panel_text_auth.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_text_auth.Location = new System.Drawing.Point(0, 0);
            this.panel_text_auth.Name = "panel_text_auth";
            this.panel_text_auth.Size = new System.Drawing.Size(549, 31);
            this.panel_text_auth.TabIndex = 2;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Red;
            this.button_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_close.FlatAppearance.BorderSize = 0;
            this.button_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_close.Location = new System.Drawing.Point(525, -1);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(22, 20);
            this.button_close.TabIndex = 1;
            this.button_close.Text = "X";
            this.button_close.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.button_close.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button_close.UseVisualStyleBackColor = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // FormUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 387);
            this.Controls.Add(this.panel_user);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormUser";
            this.panel_user.ResumeLayout(false);
            this.panel_user.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_res)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_molm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_chemSub)).EndInit();
            this.panel_text_auth.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_user1;
        private System.Windows.Forms.Panel panel_user;
        private System.Windows.Forms.Panel panel_text_auth;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox_sub;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox_res;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_molm;
        private System.Windows.Forms.Button button_add_sub;
        private System.Windows.Forms.Button button_add_res;
        private System.Windows.Forms.Button button_add_molm;
        private System.Windows.Forms.DataGridView dataGridView_res;
        private System.Windows.Forms.DataGridView dataGridView_molm;
        private System.Windows.Forms.DataGridView dataGridView_chemSub;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.Button button_cleanAll;
        private System.Windows.Forms.Button button_exit;
    }
}