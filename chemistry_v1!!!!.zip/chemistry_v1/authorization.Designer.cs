﻿
namespace chemistry_v1
{
    partial class authorization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_auth = new System.Windows.Forms.Panel();
            this.panel_text_auth = new System.Windows.Forms.Panel();
            this.button_close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button_expert_auth = new System.Windows.Forms.Button();
            this.button_user_auth = new System.Windows.Forms.Button();
            this.panel_auth.SuspendLayout();
            this.panel_text_auth.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_auth
            // 
            this.panel_auth.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel_auth.Controls.Add(this.panel_text_auth);
            this.panel_auth.Controls.Add(this.button_expert_auth);
            this.panel_auth.Controls.Add(this.button_user_auth);
            this.panel_auth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_auth.Location = new System.Drawing.Point(0, 0);
            this.panel_auth.Name = "panel_auth";
            this.panel_auth.Size = new System.Drawing.Size(320, 335);
            this.panel_auth.TabIndex = 0;
            this.panel_auth.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_auth_MouseDown);
            this.panel_auth.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_auth_MouseMove);
            // 
            // panel_text_auth
            // 
            this.panel_text_auth.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_text_auth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_text_auth.Controls.Add(this.button_close);
            this.panel_text_auth.Controls.Add(this.label1);
            this.panel_text_auth.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_text_auth.Location = new System.Drawing.Point(0, 0);
            this.panel_text_auth.Name = "panel_text_auth";
            this.panel_text_auth.Size = new System.Drawing.Size(320, 59);
            this.panel_text_auth.TabIndex = 2;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Red;
            this.button_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_close.FlatAppearance.BorderSize = 0;
            this.button_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_close.Location = new System.Drawing.Point(297, -1);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(22, 20);
            this.button_close.TabIndex = 1;
            this.button_close.Text = "X";
            this.button_close.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.button_close.UseVisualStyleBackColor = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(318, 57);
            this.label1.TabIndex = 0;
            this.label1.Text = "Авторизация";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label1_MouseDown);
            this.label1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label1_MouseMove);
            // 
            // button_expert_auth
            // 
            this.button_expert_auth.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button_expert_auth.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.button_expert_auth.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.button_expert_auth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_expert_auth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_expert_auth.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_expert_auth.Location = new System.Drawing.Point(79, 169);
            this.button_expert_auth.Name = "button_expert_auth";
            this.button_expert_auth.Size = new System.Drawing.Size(160, 48);
            this.button_expert_auth.TabIndex = 1;
            this.button_expert_auth.Text = "Эксперт";
            this.button_expert_auth.UseVisualStyleBackColor = false;
            this.button_expert_auth.Click += new System.EventHandler(this.button_expert_auth_Click);
            // 
            // button_user_auth
            // 
            this.button_user_auth.BackColor = System.Drawing.SystemColors.HotTrack;
            this.button_user_auth.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Green;
            this.button_user_auth.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.button_user_auth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_user_auth.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_user_auth.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_user_auth.Location = new System.Drawing.Point(79, 96);
            this.button_user_auth.Name = "button_user_auth";
            this.button_user_auth.Size = new System.Drawing.Size(161, 48);
            this.button_user_auth.TabIndex = 0;
            this.button_user_auth.Text = "Пользователь";
            this.button_user_auth.UseVisualStyleBackColor = false;
            this.button_user_auth.Click += new System.EventHandler(this.button_user_auth_Click);
            // 
            // authorization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 335);
            this.Controls.Add(this.panel_auth);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "authorization";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация";
            this.panel_auth.ResumeLayout(false);
            this.panel_text_auth.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_auth;
        private System.Windows.Forms.Panel panel_text_auth;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_expert_auth;
        private System.Windows.Forms.Button button_user_auth;
        private System.Windows.Forms.Button button_close;
    }
}