﻿
namespace chemistry_v1
{
    partial class FormUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_user1 = new System.Windows.Forms.Label();
            this.panel_user = new System.Windows.Forms.Panel();
            this.panel_text_auth = new System.Windows.Forms.Panel();
            this.button_close = new System.Windows.Forms.Button();
            this.panel_user.SuspendLayout();
            this.panel_text_auth.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_user1
            // 
            this.label_user1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label_user1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_user1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_user1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label_user1.Location = new System.Drawing.Point(0, 0);
            this.label_user1.Name = "label_user1";
            this.label_user1.Size = new System.Drawing.Size(547, 29);
            this.label_user1.TabIndex = 0;
            this.label_user1.Text = "Ввод исходных данных";
            this.label_user1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel_user
            // 
            this.panel_user.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel_user.Controls.Add(this.panel_text_auth);
            this.panel_user.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_user.Location = new System.Drawing.Point(0, 0);
            this.panel_user.Name = "panel_user";
            this.panel_user.Size = new System.Drawing.Size(549, 387);
            this.panel_user.TabIndex = 2;
            // 
            // panel_text_auth
            // 
            this.panel_text_auth.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_text_auth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_text_auth.Controls.Add(this.button_close);
            this.panel_text_auth.Controls.Add(this.label_user1);
            this.panel_text_auth.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_text_auth.Location = new System.Drawing.Point(0, 0);
            this.panel_text_auth.Name = "panel_text_auth";
            this.panel_text_auth.Size = new System.Drawing.Size(549, 31);
            this.panel_text_auth.TabIndex = 2;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Red;
            this.button_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_close.FlatAppearance.BorderSize = 0;
            this.button_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_close.Location = new System.Drawing.Point(525, -1);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(22, 20);
            this.button_close.TabIndex = 1;
            this.button_close.Text = "X";
            this.button_close.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.button_close.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button_close.UseVisualStyleBackColor = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // FormUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(549, 387);
            this.Controls.Add(this.panel_user);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormUser";
            this.panel_user.ResumeLayout(false);
            this.panel_text_auth.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_user1;
        private System.Windows.Forms.Panel panel_user;
        private System.Windows.Forms.Panel panel_text_auth;
        private System.Windows.Forms.Button button_close;
    }
}