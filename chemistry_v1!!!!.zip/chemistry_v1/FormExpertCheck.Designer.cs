﻿
namespace chemistry_v1
{
    partial class FormExpertCheck
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_expert = new System.Windows.Forms.Panel();
            this.button_check = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.panel_chem_sub = new System.Windows.Forms.Panel();
            this.button_res = new System.Windows.Forms.Button();
            this.button_reagent = new System.Windows.Forms.Button();
            this.button_reaction = new System.Windows.Forms.Button();
            this.button_mol_m = new System.Windows.Forms.Button();
            this.button_chem_sub = new System.Windows.Forms.Button();
            this.panel_text_auth = new System.Windows.Forms.Panel();
            this.button_close = new System.Windows.Forms.Button();
            this.label_editBZ = new System.Windows.Forms.Label();
            this.panel_expert.SuspendLayout();
            this.panel_text_auth.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_expert
            // 
            this.panel_expert.BackColor = System.Drawing.SystemColors.Menu;
            this.panel_expert.Controls.Add(this.button_check);
            this.panel_expert.Controls.Add(this.button_exit);
            this.panel_expert.Controls.Add(this.panel_chem_sub);
            this.panel_expert.Controls.Add(this.button_res);
            this.panel_expert.Controls.Add(this.button_reagent);
            this.panel_expert.Controls.Add(this.button_reaction);
            this.panel_expert.Controls.Add(this.button_mol_m);
            this.panel_expert.Controls.Add(this.button_chem_sub);
            this.panel_expert.Controls.Add(this.panel_text_auth);
            this.panel_expert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_expert.Location = new System.Drawing.Point(0, 0);
            this.panel_expert.Name = "panel_expert";
            this.panel_expert.Size = new System.Drawing.Size(548, 447);
            this.panel_expert.TabIndex = 5;
            this.panel_expert.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_expert_MouseDown);
            this.panel_expert.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_expert_MouseMove);
            // 
            // button_check
            // 
            this.button_check.BackColor = System.Drawing.Color.ForestGreen;
            this.button_check.FlatAppearance.BorderSize = 0;
            this.button_check.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_check.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_check.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_check.Location = new System.Drawing.Point(0, 357);
            this.button_check.Name = "button_check";
            this.button_check.Size = new System.Drawing.Size(113, 51);
            this.button_check.TabIndex = 10;
            this.button_check.Text = "Проверка полноты знаний ";
            this.button_check.UseVisualStyleBackColor = false;
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.button_exit.FlatAppearance.BorderSize = 0;
            this.button_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_exit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_exit.Location = new System.Drawing.Point(0, 414);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(107, 21);
            this.button_exit.TabIndex = 9;
            this.button_exit.Text = "Выйти";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // panel_chem_sub
            // 
            this.panel_chem_sub.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_chem_sub.Location = new System.Drawing.Point(113, 37);
            this.panel_chem_sub.Name = "panel_chem_sub";
            this.panel_chem_sub.Size = new System.Drawing.Size(423, 398);
            this.panel_chem_sub.TabIndex = 8;
            // 
            // button_res
            // 
            this.button_res.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_res.FlatAppearance.BorderSize = 0;
            this.button_res.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_res.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_res.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_res.Location = new System.Drawing.Point(0, 213);
            this.button_res.Name = "button_res";
            this.button_res.Size = new System.Drawing.Size(107, 38);
            this.button_res.TabIndex = 7;
            this.button_res.Text = "Результаты ";
            this.button_res.UseVisualStyleBackColor = false;
            this.button_res.Click += new System.EventHandler(this.button_res_Click);
            // 
            // button_reagent
            // 
            this.button_reagent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_reagent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_reagent.FlatAppearance.BorderSize = 0;
            this.button_reagent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reagent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_reagent.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_reagent.Location = new System.Drawing.Point(0, 169);
            this.button_reagent.Name = "button_reagent";
            this.button_reagent.Size = new System.Drawing.Size(107, 38);
            this.button_reagent.TabIndex = 6;
            this.button_reagent.Text = "Реагенты";
            this.button_reagent.UseVisualStyleBackColor = false;
            this.button_reagent.Click += new System.EventHandler(this.button_reagent_Click);
            // 
            // button_reaction
            // 
            this.button_reaction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_reaction.FlatAppearance.BorderSize = 0;
            this.button_reaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_reaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_reaction.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_reaction.Location = new System.Drawing.Point(0, 125);
            this.button_reaction.Name = "button_reaction";
            this.button_reaction.Size = new System.Drawing.Size(107, 38);
            this.button_reaction.TabIndex = 5;
            this.button_reaction.Text = "Реакции";
            this.button_reaction.UseVisualStyleBackColor = false;
            this.button_reaction.Click += new System.EventHandler(this.button_reaction_Click);
            // 
            // button_mol_m
            // 
            this.button_mol_m.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_mol_m.FlatAppearance.BorderSize = 0;
            this.button_mol_m.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_mol_m.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_mol_m.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_mol_m.Location = new System.Drawing.Point(0, 81);
            this.button_mol_m.Name = "button_mol_m";
            this.button_mol_m.Size = new System.Drawing.Size(107, 38);
            this.button_mol_m.TabIndex = 4;
            this.button_mol_m.Text = "Молярная масса";
            this.button_mol_m.UseVisualStyleBackColor = false;
            this.button_mol_m.Click += new System.EventHandler(this.button_mol_m_Click);
            // 
            // button_chem_sub
            // 
            this.button_chem_sub.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button_chem_sub.FlatAppearance.BorderSize = 0;
            this.button_chem_sub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_chem_sub.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_chem_sub.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_chem_sub.Location = new System.Drawing.Point(0, 37);
            this.button_chem_sub.Name = "button_chem_sub";
            this.button_chem_sub.Size = new System.Drawing.Size(107, 38);
            this.button_chem_sub.TabIndex = 3;
            this.button_chem_sub.Text = "Химические вещества";
            this.button_chem_sub.UseVisualStyleBackColor = false;
            this.button_chem_sub.Click += new System.EventHandler(this.button_chem_sub_Click);
            // 
            // panel_text_auth
            // 
            this.panel_text_auth.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel_text_auth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_text_auth.Controls.Add(this.button_close);
            this.panel_text_auth.Controls.Add(this.label_editBZ);
            this.panel_text_auth.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_text_auth.Location = new System.Drawing.Point(0, 0);
            this.panel_text_auth.Name = "panel_text_auth";
            this.panel_text_auth.Size = new System.Drawing.Size(548, 31);
            this.panel_text_auth.TabIndex = 2;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Red;
            this.button_close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_close.FlatAppearance.BorderSize = 0;
            this.button_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button_close.Location = new System.Drawing.Point(525, -1);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(22, 20);
            this.button_close.TabIndex = 1;
            this.button_close.Text = "X";
            this.button_close.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.button_close.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.button_close.UseVisualStyleBackColor = false;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // label_editBZ
            // 
            this.label_editBZ.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label_editBZ.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_editBZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_editBZ.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label_editBZ.Location = new System.Drawing.Point(0, 0);
            this.label_editBZ.Name = "label_editBZ";
            this.label_editBZ.Size = new System.Drawing.Size(546, 29);
            this.label_editBZ.TabIndex = 0;
            this.label_editBZ.Text = "Редактор базы знаний";
            this.label_editBZ.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_editBZ.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label_editBZ_MouseDown);
            this.label_editBZ.MouseMove += new System.Windows.Forms.MouseEventHandler(this.label_editBZ_MouseMove);
            // 
            // FormExpertCheck
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 447);
            this.Controls.Add(this.panel_expert);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormExpertCheck";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormExpertCheck";
            this.panel_expert.ResumeLayout(false);
            this.panel_text_auth.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_expert;
        private System.Windows.Forms.Button button_check;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Panel panel_chem_sub;
        private System.Windows.Forms.Button button_res;
        private System.Windows.Forms.Button button_reagent;
        private System.Windows.Forms.Button button_reaction;
        private System.Windows.Forms.Button button_mol_m;
        private System.Windows.Forms.Button button_chem_sub;
        private System.Windows.Forms.Panel panel_text_auth;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Label label_editBZ;
    }
}