﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chemistry_v1
{
    public partial class FormExpertRes : Form
    {
        public FormExpertRes()
        {
            InitializeComponent();
            FillList_reaction();
            FillList_sub();
            ShowTable();
        }

        public void ShowTable()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `reaction`.`name_reaction`, `chem_sub`.`name_chem` FROM `res` JOIN `reaction` ON `res`.`id_reaction` = `reaction`.`id_reaction` JOIN `chem_sub` ON `res`.`id_sub` = `chem_sub`.`id_chem`; ", db.getConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView_res.DataSource = table;
        }

        public void FillList_reaction()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `name_reaction` FROM `reaction`", db.getConnection());


            db.openConnecntion();
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                listBox_reaction.Items.Add(reader["name_reaction"].ToString());
            }

            reader.Close();
            db.closeConnecntion();

        }

        public void FillList_sub()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `name_chem` FROM `chem_sub`", db.getConnection());


            db.openConnecntion();
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                listBox_res.Items.Add(reader["name_chem"].ToString());
            }

            reader.Close();
            db.closeConnecntion();

        }

        public Boolean isNameExist()
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM `res` JOIN `reaction` ON `reaction`.`id_reaction` = `res`.`id_reaction` WHERE `reaction`.`name_reaction` = @nameReaction", db.getConnection());
            command.Parameters.Add("@nameReaction", MySqlDbType.VarChar).Value = listBox_reaction.SelectedItem;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Результат с этой реакцией уже существует!");
                return true;
            }
            else
            {
                return false;
            }
        }

        public int ShareId(object nameSub)
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `id_chem` FROM `chem_sub` WHERE `name_chem` = @nameSub", db.getConnection());

            command.Parameters.Add("@nameSub", MySqlDbType.VarChar).Value = nameSub.ToString();

            int id = 0;

            db.openConnecntion();

            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    id = Convert.ToInt32(reader["id_chem"]);
                }
            }

            db.closeConnecntion();

            return id;
        }

        public int ShareId_R(object name_reaction)
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT `id_reaction` FROM `reaction` WHERE `name_reaction` = @name_reaction", db.getConnection());

            command.Parameters.Add("@name_reaction", MySqlDbType.VarChar).Value = name_reaction.ToString();

            int id = 0;

            db.openConnecntion();

            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    id = Convert.ToInt32(reader["id_reaction"]);
                }
            }

            db.closeConnecntion();

            return id;
        }

        private void button_chem_sub_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpert formExpert = new FormExpert();
            formExpert.Show();
        }

        private void button_mol_m_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertMolM molm = new FormExpertMolM();
            molm.Show();
        }

        private void button_reaction_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertReaction reaction = new FormExpertReaction();
            reaction.Show();
        }

        private void button_reagent_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertReagent reagent = new FormExpertReagent();
            reagent.Show();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            authorization autho = new authorization();
            autho.Show();
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        Point lastPoint;
        private void panel_expert_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel_expert_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void label_editBZ_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void label_editBZ_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void button_check_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertCheck form = new FormExpertCheck();
            form.Show();
        }

        private void button_res_Click(object sender, EventArgs e)
        {

        }

        private void button_add_Click(object sender, EventArgs e)
        {
            if ((listBox_reaction.SelectedIndex == -1) || (listBox_res.SelectedIndex == -1))
            {
                MessageBox.Show("Выберите все элементы!");
                return;
            }

            if (isNameExist())
            {
                return;
            }

            DB db = new DB();
            MySqlCommand command = new MySqlCommand("INSERT INTO `res` (`id_reaction`,`id_sub`) VALUES (@idReaction, @idSub)", db.getConnection());

            command.Parameters.Add("@idReaction", MySqlDbType.Int32).Value = ShareId_R(listBox_reaction.SelectedItem);
            command.Parameters.Add("@idSub", MySqlDbType.Int32).Value = ShareId(listBox_res.SelectedItem);

            db.openConnecntion();

            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Новый результат добавлен.");
                ShowTable();
            }
            else
            {
                MessageBox.Show("Результат не добавлен.");
            }

            db.closeConnecntion();
        }

        private void button_restart_Click(object sender, EventArgs e)
        {
            ShowTable();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            if (dataGridView_res.SelectedRows.Count > 0)
            {
                DB db = new DB();
                MySqlCommand command = new MySqlCommand("DELETE FROM res WHERE id_reaction = @idReaction", db.getConnection());
                DataGridViewRow row = new DataGridViewRow();
                row = dataGridView_res.SelectedRows[0];
                command.Parameters.Add("@idReaction", MySqlDbType.Int32).Value = ShareId_R(row.Cells[0].Value.ToString());

                db.openConnecntion();
                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Результат удален.");
                    ShowTable();
                }
                else
                {
                    MessageBox.Show("Резултат не удален.");
                }
                db.closeConnecntion();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите строку!");
            }
        }
    }
}
