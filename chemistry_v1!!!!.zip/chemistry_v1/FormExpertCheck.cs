﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chemistry_v1
{
    public partial class FormExpertCheck : Form
    {
        public FormExpertCheck()
        {
            InitializeComponent();
        }

        private void button_chem_sub_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpert form = new FormExpert();
            form.Show();
        }

        private void button_mol_m_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertMolM form = new FormExpertMolM();
            form.Show();
        }

        private void button_reaction_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertReaction form = new FormExpertReaction();
            form.Show();
        }

        private void button_reagent_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertReagent form = new FormExpertReagent();
            form.Show();
        }

        private void button_res_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormExpertRes form = new FormExpertRes();
            form.Show();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            this.Hide();
            authorization form = new authorization();
            form.Show();
        }

        private void button_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        Point lastPoint;
        private void panel_expert_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel_expert_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void label_editBZ_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void label_editBZ_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }
    }
}
